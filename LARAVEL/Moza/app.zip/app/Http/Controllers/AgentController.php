<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Agent;
use App\Models\User;

class AgentController extends Controller
{
    public function index()
    {
        $agents = Agent::with('user')->get()->map(function ($agent) {
            return [
                'agent_id' => $agent->agent_id,
                'name' => $agent->name,
                'email' => $agent->email,
                'phone_number' => $agent->phone_number,
                'state' => $agent->state,
                'branch' => $agent->branch,
            ];
        });

        return response()->json($agents);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email|exists:users,email',
            'agent_id' => 'required|unique:agents,agent_id',
            'name' => 'required|string|max:255',
            'phone_number' => 'required|string|max:20',
            'state' => 'required|string|max:100',
            'branch' => 'required|string|max:100',
        ]);

        $user = User::where('email', $validated['email'])->first();

        $agent = Agent::create([
            'agent_id' => $validated['agent_id'],
            'user_id' => $user->id,
            'name' => $validated['name'],
            'email' => $validated['email'],
            'phone_number' => $validated['phone_number'],
            'state' => $validated['state'],
            'branch' => $validated['branch'],
        ]);

        return response()->json([
            'message' => 'Agent registered successfully',
            'agent' => $agent
        ], 201);
    }
}
