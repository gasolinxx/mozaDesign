<?php

namespace App\Http\Controllers;

use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ProductVariantController extends Controller
{
    // GET: /api/variants
    public function index()
    {
        return ProductVariant::with('subproduct.product')->get();
    }

    // GET: /api/variants/subproduct/{id}
    public function getBySubproduct($subproductId)
    {
        return ProductVariant::where('subproduct_id', $subproductId)->get();
    }

    // POST: /api/variants
 public function store(Request $request)
{
    Log::info('Variant Data:', $request->all());

    $validated = $request->validate([
        'subproduct_id' => 'required|exists:subproducts,id',
        'material' => 'nullable|string',
        'size' => 'nullable|string',
        'color' => 'nullable|string',
        'type' => 'nullable|string',
        'printing_side' => 'nullable|string',
        'offset' => 'nullable|boolean', // ✅ updated!
        'agent_price' => 'nullable|numeric',
        'customer_price' => 'nullable|numeric',
        'notes' => 'nullable|string',
    ]);

    $variant = ProductVariant::create($validated);

    return response()->json($variant, 201);
}
}