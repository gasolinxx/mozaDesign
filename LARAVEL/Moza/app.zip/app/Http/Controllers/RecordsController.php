<?php
namespace App\Http\Controllers;

use App\Models\ProductVariant;
use Illuminate\Http\Request;

class RecordsController extends Controller
{
    public function getAllProductRecords()
    {
        $variants = ProductVariant::with([
            'subproduct.product.category'
        ])->get();

        $records = $variants->map(function ($variant) {
            return [
                'variant_id' => $variant->id,
                'category' => $variant->subproduct->product->category->name ?? '',
                'product' => $variant->subproduct->product->name ?? '',
                'subproduct' => $variant->subproduct->name ?? '',
                'material' => $variant->material,
                'size' => $variant->size,
                'color' => $variant->color,
                'type' => $variant->type,
                'printing_side' => $variant->printing_side,
                'offset' => $variant->offset,
                'agent_price' => $variant->agent_price,
                'customer_price' => $variant->customer_price,
                'notes' => $variant->notes,
            ];
        });

        return response()->json($records);
    }
    public function deleteVariant($id)
{
    echo "Delete request received for ID: $id"; // 👈 Check if this even runs

    $variant = ProductVariant::find($id);

    if (!$variant) {
        echo "Variant not found";
        return response()->json(['message' => 'Variant not found'], 404);
    }

    $variant->delete();
    echo "Deleted successfully";

    return response()->json(['message' => 'Variant deleted successfully']);
}


public function updateVariant(Request $request, $id)
{
    try {
        // Find the variant
        $variant = ProductVariant::findOrFail($id);

        // Update fields
        $variant->material = $request->input('material');
        $variant->size = $request->input('size');
        $variant->color = $request->input('color');
        $variant->type = $request->input('type');
        $variant->printing_side = $request->input('printing_side');
        $variant->offset = $request->input('offset');
        $variant->agent_price = $request->input('agent_price');
        $variant->customer_price = $request->input('customer_price');
        $variant->notes = $request->input('notes');

        $variant->save();

        return response()->json(['message' => 'Variant updated successfully']);
    } catch (\Exception $e) {
        return response()->json([
            'message' => 'Failed to update variant',
            'error' => $e->getMessage()
        ], 500);
    }
}
}