<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductVariant extends Model
{
    use HasFactory;

    protected $fillable = [
        'subproduct_id',
        'material',
        'size',
        'color',
        'type',
        'printing_side',
        'offset',
        'agent_price',
        'customer_price',
        'notes',
    ];

    public function subproduct()
    {
        return $this->belongsTo(Subproduct::class);
    }
}
