<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Agent extends Model
{
    protected $table = 'agents';
    protected $primaryKey = 'agent_id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'agent_id',
        'user_id',
        'name',
        'email',
        'phone_number',
        'state',
        'branch'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
